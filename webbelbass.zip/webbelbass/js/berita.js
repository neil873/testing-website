let berita = JSON.parse(localStorage.getItem("berita")) || [];

if (berita.length === 0) {
  fetch("data/berita.json")
    .then(res => res.json())
    .then(data => {
      localStorage.setItem("berita", JSON.stringify(data));
      location.reload();
    });
}

/* =====================
   SEMUA BERITA
===================== */
const list = document.getElementById("berita-list");
if (list) {
  berita.forEach(b => {
    list.innerHTML += `
      <div class="berita-card">
        <div class="berita-img">
          <img src="${b.gambar}">
          <span class="berita-badge">${b.kategori}</span>
        </div>
        <div class="berita-content">
          <span class="berita-date">${b.tanggal}</span>
          <h3>${b.judul}</h3>
          <p>${b.ringkas}</p>
          <a href="berita-detail.html?id=${b.id}" class="berita-btn">
            Baca Selengkapnya
          </a>
        </div>
      </div>
    `;
  });
}

/* =====================
   DETAIL BERITA
===================== */
const detail = document.getElementById("berita-detail");
if (detail) {
  const id = new URLSearchParams(window.location.search).get("id");
  const b = berita.find(x => x.id == id);

  if (b) {
    detail.innerHTML = `
      <h1>${b.judul}</h1>
      <span>${b.tanggal}</span>
      <img src="${b.gambar}">
      <p>${b.isi}</p>
    `;
  }
}