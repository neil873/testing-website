function loginAdmin(){
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const error = document.getElementById("errorLogin");

  // USERNAME & PASSWORD ADMIN
  const ADMIN_USER = "admin";
  const ADMIN_PASS = "12345";

  if(username === ADMIN_USER && password === ADMIN_PASS){
    localStorage.setItem("isAdmin", "true");
    window.location.href = "admin.html";
  } else {
    error.textContent = "Username atau password salah!";
  }
}