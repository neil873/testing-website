/* ===============================
   ANIMASI SCROLL (FADE UP)
================================ */
const observer = new IntersectionObserver(
  entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("show");
      }
    });
  },
  { threshold: 0.15 }
);

document.querySelectorAll(".mts-section, .school-card").forEach(el => {
  el.classList.add("fade-up");
  observer.observe(el);
});

/* ===============================
   MODAL CAMP
================================ */
const modal = document.createElement("div");
modal.className = "mts-modal";
modal.innerHTML = `
  <div class="modal-content">
    <div class="modal-header">
      <h3 id="modalTitle">Program Camp</h3>
      <span class="modal-close">&times;</span>
    </div>
    <p id="modalDesc">
      Deskripsi program camp akan ditampilkan di sini.
    </p>
  </div>
`;
document.body.appendChild(modal);

const modalTitle = modal.querySelector("#modalTitle");
const modalDesc = modal.querySelector("#modalDesc");
const closeBtn = modal.querySelector(".modal-close");

document.querySelectorAll(".modal-btn").forEach(btn => {
  btn.addEventListener("click", e => {
    e.preventDefault();

    const target = btn.dataset.target;
    modalTitle.textContent =
      target.replace("-", " ").toUpperCase();
    modalDesc.textContent =
      "Program ini merupakan bagian dari unggulan MTs eL-BAS yang berfokus pada pembinaan bahasa dan karakter santri.";

    modal.classList.add("active");
  });
});

closeBtn.onclick = () => modal.classList.remove("active");
modal.onclick = e => {
  if (e.target === modal) modal.classList.remove("active");
};