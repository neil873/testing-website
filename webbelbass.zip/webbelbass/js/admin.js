const form = document.getElementById("formBerita");
const adminList = document.getElementById("adminList");

let berita = JSON.parse(localStorage.getItem("berita")) || [];
let editId = null;

/* =====================
   RENDER LIST
===================== */
function renderList() {
  adminList.innerHTML = "";

  if (berita.length === 0) {
    adminList.innerHTML = "<p>Belum ada berita</p>";
    return;
  }

  berita.forEach(b => {
    adminList.innerHTML += `
      <div class="berita-card" style="margin-bottom:15px">
        <h4>${b.judul}</h4>
        <small>${b.tanggal} • ${b.kategori}</small>

        <div style="margin-top:10px">
          <button onclick="editBerita(${b.id})">✏ Edit</button>
          <button onclick="hapusBerita(${b.id})" style="background:#c62828;color:#fff">
            🗑 Hapus
          </button>
        </div>
      </div>
    `;
  });
}

/* =====================
   TAMBAH / UPDATE
===================== */
form.addEventListener("submit", function(e) {
  e.preventDefault();

  const data = {
    id: editId ?? Date.now(),
    judul: judul.value,
    tanggal: tanggal.value,
    kategori: kategori.value,
    gambar: gambar.value,
    ringkas: ringkas.value,
    isi: isi.value
  };

  if (editId) {
    berita = berita.map(b => b.id === editId ? data : b);
    editId = null;
    alert("Berita berhasil diupdate!");
  } else {
    berita.unshift(data);
    alert("Berita berhasil ditambahkan!");
  }

  localStorage.setItem("berita", JSON.stringify(berita));
  form.reset();
  renderList();
});

/* =====================
   EDIT
===================== */
window.editBerita = function(id) {
  const b = berita.find(x => x.id === id);
  if (!b) return;

  editId = id;

  judul.value = b.judul;
  tanggal.value = b.tanggal;
  kategori.value = b.kategori;
  gambar.value = b.gambar;
  ringkas.value = b.ringkas;
  isi.value = b.isi;

  window.scrollTo({ top: 0, behavior: "smooth" });
};

/* =====================
   HAPUS
===================== */
window.hapusBerita = function(id) {
  if (!confirm("Yakin hapus berita ini?")) return;

  berita = berita.filter(b => b.id !== id);
  localStorage.setItem("berita", JSON.stringify(berita));
  renderList();
};

/* INIT */
renderList();
/* =====================
   GALERI
===================== */
const formGaleri = document.getElementById("formGaleri");
const galeriAdminList = document.getElementById("galeriAdminList");

let galeri = JSON.parse(localStorage.getItem("galeri")) || [];

/* Render Galeri Admin */
function renderGaleriAdmin() {
  galeriAdminList.innerHTML = "";

  if (galeri.length === 0) {
    galeriAdminList.innerHTML = "<p>Belum ada foto galeri</p>";
    return;
  }

  galeri.forEach((g, i) => {
    galeriAdminList.innerHTML += `
      <div class="berita-card">
        <img src="${g.foto}" style="width:100%;border-radius:10px">
        <p style="margin:10px 0">${g.caption}</p>
        <button onclick="hapusGaleri(${i})"
          style="background:#c62828;color:#fff">
          🗑 Hapus
        </button>
      </div>
    `;
  });
}

/* Tambah Galeri */
formGaleri.addEventListener("submit", function(e) {
  e.preventDefault();

  const file = galeriFoto.files[0];
  const caption = galeriCaption.value;

  const reader = new FileReader();
  reader.onload = function() {
    galeri.unshift({
      foto: reader.result,
      caption: caption
    });

    localStorage.setItem("galeri", JSON.stringify(galeri));
    formGaleri.reset();
    renderGaleriAdmin();
  };

  reader.readAsDataURL(file);
});

/* Hapus Galeri */
window.hapusGaleri = function(index) {
  if (!confirm("Hapus foto ini?")) return;
  galeri.splice(index, 1);
  localStorage.setItem("galeri", JSON.stringify(galeri));
  renderGaleriAdmin();
};

/* INIT */
renderGaleriAdmin();